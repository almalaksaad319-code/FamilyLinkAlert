package com.familylinkalert

import android.app.*
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.*
import android.content.Context
import android.content.Intent
import android.os.*
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.UUID

class ProximityService : Service() {
    private var scanner: BluetoothLeScanner? = null
    private var advertiser: BluetoothLeAdvertiser? = null
    private var scanCallback: ScanCallback? = null
    private var advertiseCallback: AdvertiseCallback? = null
    private val handler = Handler(Looper.getMainLooper())
    private var lastSeen = 0L
    private var weakSamples = 0
    private var alarmActive = false
    private var threshold = -76
    private var serviceUuid: UUID = UUID.fromString("7c2e0000-0000-4000-8000-000000000001")
    private var tone: ToneGenerator? = null

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getStringExtra("pair_code") ?: return START_NOT_STICKY
        threshold = intent.getIntExtra("rssi_threshold", -76)
        serviceUuid = uuidForCode(code)
        startForeground(7, makeNotification("المراقبة تعمل"))
        startBle()
        handler.removeCallbacks(timeoutCheck)
        handler.post(timeoutCheck)
        return START_STICKY
    }

    private fun uuidForCode(code: String): UUID {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(("FamilyLinkAlert:" + code).toByteArray(StandardCharsets.UTF_8))
        val b = digest.copyOfRange(0, 16)
        b[6] = ((b[6].toInt() and 0x0f) or 0x50).toByte()
        b[8] = ((b[8].toInt() and 0x3f) or 0x80).toByte()
        val bb = java.nio.ByteBuffer.wrap(b)
        return UUID(bb.long, bb.long)
    }

    private fun makeNotification(message: String): Notification {
        val channelId = "proximity_alert"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                channelId, "مراقبة القرب", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return Notification.Builder(this, channelId)
            .setContentTitle("Family Link Alert")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }

    private fun startBle() {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        scanner = adapter.bluetoothLeScanner
        advertiser = adapter.bluetoothLeAdvertiser
        if (scanner == null || advertiser == null) {
            updateNotification("هذا الهاتف لا يدعم BLE advertising/scanning")
            return
        }

        val parcelUuid = android.os.ParcelUuid(serviceUuid)
        val adSettings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .setConnectable(false)
            .build()
        val adData = AdvertiseData.Builder()
            .addServiceUuid(parcelUuid)
            .setIncludeDeviceName(false)
            .build()

        advertiseCallback = object : AdvertiseCallback() {
            override fun onStartFailure(errorCode: Int) {
                Log.e("FamilyLink", "Advertise failed: $errorCode")
                updateNotification("تعذر بث إشارة Bluetooth")
            }
        }
        try {
            advertiser?.startAdvertising(adSettings, adData, advertiseCallback)
        } catch (e: SecurityException) {
            updateNotification("يرجى السماح بصلاحيات Bluetooth")
        }

        val filter = ScanFilter.Builder().setServiceUuid(parcelUuid).build()
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .setReportDelay(0)
            .build()

        scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                lastSeen = System.currentTimeMillis()
                if (result.rssi < threshold) weakSamples++ else weakSamples = 0
                if (weakSamples >= 5) triggerAlarm("يبدو أن الهاتف الآخر يبتعد")
                else if (result.rssi >= threshold) clearAlarm()
            }
            override fun onScanFailed(errorCode: Int) {
                updateNotification("تعذر البحث عن الهاتف الآخر: $errorCode")
            }
        }
        try {
            scanner?.startScan(listOf(filter), settings, scanCallback)
        } catch (e: SecurityException) {
            updateNotification("يرجى السماح بصلاحيات Bluetooth")
        }
        lastSeen = System.currentTimeMillis()
    }

    private val timeoutCheck = object : Runnable {
        override fun run() {
            if (lastSeen != 0L && System.currentTimeMillis() - lastSeen > 9000L) {
                triggerAlarm("فُقدت إشارة الهاتف الآخر")
            }
            handler.postDelayed(this, 2000L)
        }
    }

    private fun triggerAlarm(message: String) {
        if (alarmActive) return
        alarmActive = true
        updateNotification(message)
        try {
            tone = ToneGenerator(AudioManager.STREAM_ALARM, 100).also {
                it.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD)
            }
            val vibrator = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(VibratorManager::class.java).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 250, 500), 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(longArrayOf(0, 500, 250, 500), 0)
            }
        } catch (e: Exception) {
            Log.e("FamilyLink", "Alarm error", e)
        }
    }

    private fun clearAlarm() {
        if (!alarmActive) return
        alarmActive = false
        tone?.stopTone()
        tone?.release()
        tone = null
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(VibratorManager::class.java).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            vibrator.cancel()
        } catch (_: Exception) {}
        updateNotification("تم استعادة الإشارة")
    }

    private fun updateNotification(message: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(7, makeNotification(message))
    }

    override fun onDestroy() {
        handler.removeCallbacks(timeoutCheck)
        try { scanCallback?.let { scanner?.stopScan(it) } } catch (_: Exception) {}
        try { advertiseCallback?.let { advertiser?.stopAdvertising(it) } } catch (_: Exception) {}
        clearAlarm()
        super.onDestroy()
    }
}
