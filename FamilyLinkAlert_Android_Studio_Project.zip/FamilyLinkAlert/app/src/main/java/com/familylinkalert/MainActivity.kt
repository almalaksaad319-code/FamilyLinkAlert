package com.familylinkalert

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import android.view.ViewGroup

class MainActivity : Activity() {
    private lateinit var codeInput: EditText
    private lateinit var distanceSpinner: Spinner

    private fun requiredPermissions(): Array<String> {
        val p = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            p += Manifest.permission.BLUETOOTH_SCAN
            p += Manifest.permission.BLUETOOTH_ADVERTISE
            p += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            p += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        return p.toTypedArray()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        val title = TextView(this).apply {
            text = "Family Link Alert"
            textSize = 27f
        }
        val intro = TextView(this).apply {
            text = "اربط هاتفين برمز سري مشترك، ثم ابدأ مراقبة القرب عبر Bluetooth دون إنترنت."
            textSize = 16f
            setPadding(0, pad, 0, pad)
        }
        codeInput = EditText(this).apply {
            hint = "أدخل رمزاً مشتركاً من 6 أرقام"
            inputType = 2
            filters = arrayOf(android.text.InputFilter.LengthFilter(6))
        }
        distanceSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("حساسية قريبة", "حساسية متوسطة", "حساسية أبعد")
            )
        }
        val start = Button(this).apply {
            text = "بدء الحماية"
            setOnClickListener { begin() }
        }
        val stop = Button(this).apply {
            text = "إيقاف الحماية"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ProximityService::class.java))
                Toast.makeText(this@MainActivity, "تم طلب إيقاف المراقبة", Toast.LENGTH_SHORT).show()
            }
        }
        val note = TextView(this).apply {
            text = "مهم: قوة Bluetooth تقديرية وليست قياساً دقيقاً بالأمتار. أبقِ Bluetooth مفعلاً واسمح بالإشعارات والعمل في الخلفية."
            textSize = 13f
            setPadding(0, pad, 0, 0)
        }

        layout.addView(title)
        layout.addView(intro)
        layout.addView(codeInput, LinearLayout.LayoutParams(-1, -2))
        layout.addView(distanceSpinner)
        layout.addView(start)
        layout.addView(stop)
        layout.addView(note)
        setContentView(layout)
    }

    private fun begin() {
        val code = codeInput.text.toString()
        if (!code.matches(Regex("\\d{6}"))) {
            codeInput.error = "أدخل 6 أرقام"
            return
        }
        val missing = requiredPermissions().filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 42)
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) {
            Toast.makeText(this, "شغّل Bluetooth أولاً", Toast.LENGTH_LONG).show()
            return
        }
        val threshold = when (distanceSpinner.selectedItemPosition) {
            0 -> -68
            1 -> -76
            else -> -83
        }
        val intent = Intent(this, ProximityService::class.java).apply {
            putExtra("pair_code", code)
            putExtra("rssi_threshold", threshold)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "بدأت المراقبة. أدخل الرمز نفسه في الهاتف الآخر.", Toast.LENGTH_LONG).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }) begin()
    }
}
